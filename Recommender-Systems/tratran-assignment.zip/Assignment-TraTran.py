import math
import random
from collections import defaultdict, Counter
from dataclasses import dataclass
from typing import List, Dict, Tuple, Set, Iterable

import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

rng_global = random.Random(42)
np_random = np.random.default_rng(42)


# -------------------------------------------------------------
#                 MOVIELENS 100K LOADING
# -------------------------------------------------------------
def load_ml100k(data_dir: str) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Returns (interactions, items).
    interactions: user_id,item_id,rating[,timestamp]
    items: item_id,title,tags (pipe-joined genres/tokens)
    """
    print("loading the data")
    try:
        ratings = pd.read_csv(f"data_dir/ratings.csv")
        movies = pd.read_csv(f"data_dir/movies.csv")
        interactions = ratings.rename(columns={"userId": "user_id", "movieId": "item_id", "timestamp": "timestamp"})
        items = movies.rename(columns={"movieId": "item_id", "genres": "tags", "title": "title"})
        interactions["user_id"] = interactions["user_id"].astype(str)
        interactions["item_id"] = interactions["item_id"].astype(str)
        items["item_id"] = items["item_id"].astype(str)
        print("Successfully loaded MovieLens 100k data.")
        return interactions[["user_id", "item_id", "rating", "timestamp"]], items[["item_id", "title", "tags"]]

    except Exception as e:
        raise FileNotFoundError(
            f"Could not load MovieLens 100k from '{data_dir}'. "
            f"Expected ratings.csv/movies.csv OR u.data/u.item. Original error: {e}"
        )
# -------------------------------------------------------------
#                 UTILS
# -------------------------------------------------------------
def top_k_indices(scores: np.ndarray, k: int) -> np.ndarray:
    if k >= len(scores):
        return np.argsort(-scores)
    idx = np.argpartition(-scores, kth=k - 1)[:k]
    return idx[np.argsort(-scores[idx])]


# -------------------------------------------------------------
#                TRAIN / TEST SPLITTING (per user)
# -------------------------------------------------------------
def train_test_split_by_user(interactions: pd.DataFrame, test_ratio: float = 0.2, seed: int = 42
                             ) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Random holdout per user. Users with <3 interactions kept fully in train."""
    rng = random.Random(seed)
    train_rows, test_rows = [], []
    for uid, g in interactions.groupby("user_id"):
        rows = list(g.itertuples(index=False))
        if len(rows) < 3:
            train_rows.extend(rows)
            continue
        k = max(1, int(len(rows) * test_ratio))
        test_idx = set(rng.sample(range(len(rows)), k))
        for i, row in enumerate(rows):
            user_id, item_id, rating, *rest = row
            rec = {"user_id": str(user_id), "item_id": str(item_id), "rating": float(rating)}
            (test_rows if i in test_idx else train_rows).append(rec)
    return pd.DataFrame(train_rows), pd.DataFrame(test_rows)


# -------------------------------------------------------------
#                 UTILS
# -------------------------------------------------------------
def top_k_indices(scores: np.ndarray, k: int) -> np.ndarray:
    if k >= len(scores):
        return np.argsort(-scores)
    idx = np.argpartition(-scores, kth=k - 1)[:k]
    return idx[np.argsort(-scores[idx])]


# -------------------------------------------------------------
#                 POPULARITY-BASED (Fully Implemented)
# -------------------------------------------------------------
@dataclass
class PopularityModel:
    item_popularity: Dict[str, float]

    @staticmethod
    def fit(train: pd.DataFrame,
            method: str = "count",
            min_interactions: int = 1,
            rating_col: str = "rating") -> 'PopularityModel':
        """
        method:
          - "count": #interactions per item
          - "sum_rating": sum of ratings
          - "avg_log_count": average_rating * log(1 + count)
          - "bayes_avg": Bayesian-smoothed average toward global mean
        """
        grp = train.groupby("item_id")
        counts = grp[rating_col].count()
        sums = grp[rating_col].sum()
        avgs = sums / counts.replace(0, np.nan)

        if method == "count":
            score = counts.astype(float)
        elif method == "sum_rating":
            score = sums.astype(float)
        elif method == "avg_log_count":
            score = avgs.fillna(0.0) * np.log1p(counts.astype(float))
        elif method == "bayes_avg":
            global_mean = train[rating_col].mean()
            m = 10.0
            score = (avgs.fillna(global_mean) * counts + global_mean * m) / (counts + m)
        else:
            raise ValueError(f"Unknown popularity method: {method}")

        if min_interactions > 1:
            score = score[counts >= min_interactions]

        return PopularityModel(item_popularity=score.to_dict())

    def recommend(self, user_seen: Set[str], k: int = 10) -> List[Tuple[str, float]]:
        cand = [(iid, s) for iid, s in self.item_popularity.items() if iid not in user_seen]
        cand.sort(key=lambda x: (-x[1], x[0]))
        return cand[:k]


# -------------------------------------------------------------
#                 CONTENT-BASED (To be completed)
# -------------------------------------------------------------
@dataclass
class ContentModel:
    X_items: np.ndarray
    item_index: Dict[str, int]
    index_item: List[str]
    vocab: Dict[str, int]

    @staticmethod
    def tokenize(tags: str) -> List[str]:
        return [t.strip().lower() for t in str(tags).replace('|', ' ').replace(',', ' ').split() if t.strip()]

    @staticmethod
    def build_item_content_matrix(items: pd.DataFrame) -> Tuple[np.ndarray, Dict[str, int], List[str], Dict[str, int]]:
        """TF-IDF over items['tags']"""
        vocab, docs, index_item = {}, [], []
        for row in items.itertuples(index=False):
            iid = str(getattr(row, "item_id"))
            tokens = ContentModel.tokenize(getattr(row, "tags"))
            docs.append(tokens)
            index_item.append(iid)
            for t in tokens:
                if t not in vocab: vocab[t] = len(vocab)
        X = np.zeros((len(index_item), len(vocab)), dtype=float)
        for i, tokens in enumerate(docs):
            for t, c in Counter(tokens).items():
                X[i, vocab[t]] = float(c)
        # IDF + normalize
        df = np.count_nonzero(X > 0, axis=0)
        idf = np.log((1 + X.shape[0]) / (1 + df)) + 1.0
        X *= idf
        norms = np.linalg.norm(X, axis=1, keepdims=True)
        norms[norms == 0] = 1.0
        X = X / norms
        item_index = {iid: i for i, iid in enumerate(index_item)}
        return X, item_index, index_item, vocab

    @staticmethod
    def fit(items: pd.DataFrame) -> 'ContentModel':
        X, item_index, index_item, vocab = ContentModel.build_item_content_matrix(items)
        return ContentModel(X_items=X, item_index=item_index, index_item=index_item, vocab=vocab)

    def build_user_profiles(self, train: pd.DataFrame, like_threshold: float = 4.0) -> Dict[str, np.ndarray]:
        """
        Build each user vector as the mean of liked item vectors (rating >= like_threshold).
        Returns dict user_id -> profile (np.ndarray shape [n_terms]).
        """
        profiles: Dict[str, np.ndarray] = {}
        for uid, g in train.groupby("user_id"):
            liked = g[g["rating"] >= like_threshold]["item_id"].astype(str).tolist()
            rows = [self.item_index[iid] for iid in liked if iid in self.item_index]
            if not rows:
                continue
            v = self.X_items[rows, :].mean(axis=0)
            n = np.linalg.norm(v)
            if n > 0: v = v / n
            profiles[str(uid)] = v
        return profiles



    def recommend(self, user_id: str, user_seen: Set[str], user_profiles: Dict[str, np.ndarray], k: int = 10
                  ) -> List[Tuple[str, float]]:
        # # --- STUDENT TODO START ---
        # If user profile does not exist → nothing to recommend
        if user_id not in user_profiles:
            print(f"[INFO] No profile found for user {user_id}")
            return []

        # 1. Get user profile
        profile = user_profiles[user_id].reshape(1, -1)
        print(f"[DEBUG] Profile vector for user {user_id} (first 5 dims): {profile[0][:5]}")

        # 2. Compute cosine similarity
        sims = cosine_similarity(profile, self.X_items)[0]
        print(f"[DEBUG] Similarity scores (first 5): {sims[:5]}")

        # 3. Exclude items already seen
        for iid in user_seen:
            if iid in self.item_index:
                sims[self.item_index[iid]] = -np.inf
        print(f"[DEBUG] Seen items excluded: {user_seen}")

        # 4. Get top-k indices
        top_idx = np.argpartition(-sims, k)[:k]
        top_idx = top_idx[np.argsort(-sims[top_idx])]

        # 5. Map back to (item_id, score)
        recs = [(self.index_item[i], sims[i]) for i in top_idx]
        print(f"[INFO] Top-{k} recommendations for user {user_id}: {recs}")

        return recs

        # # --- STUDENT TODO END ---

# === MAIN DEMO PIPELINE ===
if __name__ == "__main__":
    # 1. Load data (⚠️ fix the path issue)
    interactions, items = load_ml100k("data")

    # 2. Train/test split
    train, test = train_test_split_by_user(interactions, test_ratio=0.2)
    print(f"[INFO] Train size: {len(train)}, Test size: {len(test)}")

    # 3. Train Popularity Model
    pop_model = PopularityModel.fit(train)
    print(f"[INFO] Popularity model trained with {len(pop_model.item_popularity)} items.")

    # 4. Train Content Model
    content_model = ContentModel.fit(items)
    profiles = content_model.build_user_profiles(train)
    print(f"[INFO] Built {len(profiles)} user profiles.")

    # 5. Pick a sample user
    user_id = train["user_id"].iloc[0]  # just pick the first user in training set
    user_seen = set(train[train["user_id"] == user_id]["item_id"])
    print(f"[INFO] User {user_id} has seen {len(user_seen)} items.")

    # 6. Get popularity recommendations
    pop_recs = pop_model.recommend(user_seen, k=5)
    print(f"\n=== Popularity Recs for User {user_id} ===")
    for iid, score in pop_recs:
        title = items.loc[items["item_id"] == iid, "title"].values[0]
        print(f"{iid} | {title} | score={score:.3f}")

    # 7. Get content-based recommendations
    content_recs = content_model.recommend(user_id, user_seen, profiles, k=5)
    print(f"\n=== Content-Based Recs for User {user_id} ===")
    for iid, score in content_recs:
        title = items.loc[items["item_id"] == iid, "title"].values[0]
        print(f"{iid} | {title} | sim={score:.3f}")


# -------------------------------------------------------------
#            COLLABORATIVE FILTERING (USER-BASED) (Completely Implemented)
# -------------------------------------------------------------
@dataclass
class UserCFModel:
    user_index: Dict[str, int]
    index_user: List[str]
    item_index: Dict[str, int]
    index_item: List[str]
    R: np.ndarray  # user-item rating matrix (zeros for missing), mean-centered

    @staticmethod
    def fit(train: pd.DataFrame) -> 'UserCFModel':
        """Build dense user-item matrix and mean-center by user."""
        users = sorted(train["user_id"].astype(str).unique().tolist())
        items = sorted(train["item_id"].astype(str).unique().tolist())
        uix = {u: i for i, u in enumerate(users)}
        iix = {it: i for i, it in enumerate(items)}
        R = np.zeros((len(users), len(items)), dtype=float)
        for row in train.itertuples(index=False):
            u, it, r = str(row.user_id), str(row.item_id), float(row.rating)
            R[uix[u], iix[it]] = r
        with np.errstate(divide='ignore', invalid='ignore'):
            mask = (R > 0).astype(float)
            sums = R.sum(axis=1, keepdims=True)
            counts = mask.sum(axis=1, keepdims=True)
            means = np.divide(sums, counts, out=np.zeros_like(sums), where=counts > 0)
        R_centered = np.where(R > 0, R - means, 0.0)
        return UserCFModel(uix, users, iix, items, R_centered)

    def recommend(self, user_id: str, user_seen: Set[str], k: int = 10, top_n_neighbors: int = 25
                  ) -> List[Tuple[str, float]]:
        """
        Recommend top-k items for a given user using user-based collaborative filtering
        Parameters
        ----------
        user_id : str
            The ID of the target user.
        user_seen : set[str]
            Set of item IDs the user has already interacted with (should not be recommended again).
        k : int
            Number of recommendations to return.
        top_n_neighbors : int
            Maximum number of most similar users (neighbors) to use when aggregating scores
        Returns
        -------
        list[tuple[str, float]]
            A ranked list of (item_id, score) pairs:
              - item_id (str): ID of a recommended item
              - score (float): aggregated neighbor-based score
        """
        if user_id not in self.user_index:
            return []
        u = self.user_index[user_id]
        target_row = self.R[u].reshape(1, -1)  # (1, n_items)
        sims = cosine_similarity(target_row, self.R)[0]  # (n_users,)
        sims[u] = 0.0  # drop self
        # pick neighbors
        if top_n_neighbors < len(sims):
            nn_idx = np.argpartition(-sims, top_n_neighbors - 1)[:top_n_neighbors]
            nn_idx = nn_idx[np.argsort(-sims[nn_idx])]
        else:
            nn_idx = np.argsort(-sims)
        nn_w = sims[nn_idx]
        # weighted sum
        scores = nn_w @ self.R[nn_idx, :]
        if user_seen:
            seen_cols = [self.item_index[i] for i in user_seen if i in self.item_index]
            scores[np.array(seen_cols, dtype=int)] = -np.inf
        idx = top_k_indices(scores, k)
        return [(self.index_item[i], float(scores[i])) for i in idx if np.isfinite(scores[i])]


# -------------------------------------------------------------
#                      METRICS
# -------------------------------------------------------------
def precision_at_k(recommended: List[str], relevant: Set[str], k: int) -> float:
    """
    TODO: Precision@K = |{top-k ∩ relevant}| / k
    """
    # --- STUDENT TODO START ---
    if k <= 0:
        return 0.0
    if not recommended:
        return 0.0
    rec_k = recommended[:k]
    hits = sum(1 for i in rec_k if i in relevant)
    return hits / float(k)
    # --- STUDENT TODO END ---


def recall_at_k(recommended: List[str], relevant: Set[str], k: int) -> float:
    """Provided: Recall@K = |{top-k ∩ relevant}| / |relevant|"""
    if len(relevant) == 0: return 0.0
    rec_k = recommended[:k]
    return len([i for i in rec_k if i in relevant]) / len(relevant)


def average_precision_at_k(recommended: List[str], relevant: Set[str], k: int) -> float:
    """Provided: AP@K = average of precision@i at each hit position i<=k (binary rel)."""
    # --- STUDENT TODO START ---
    # raise NotImplementedError("average precision@k not implemented.")
    if k <= 0:
        return 0.0
    if not relevant or len(relevant) == 0:
        return 0.0
    ap_sum = 0.0
    hits = 0
    for i in range(1, k + 1):
        if i > len(recommended):
            break
        if recommended[i - 1] in relevant:
            hits += 1
            prec_i = hits / float(i)
            ap_sum += prec_i
    denom = min(len(relevant), k)
    if denom == 0:
        return 0.0
    return ap_sum / float(denom)
    # --- STUDENT TODO END ---


def ndcg_at_k(recommended: List[str], relevant: Set[str], k: int) -> float:
    """
    nDCG@K with binary relevance:
      DCG = sum_{i=1..k} rel_i / log2(i+1)
      IDCG = best possible DCG with |relevant| ones at top
    """
    dcg = 0.0
    for i, iid in enumerate(recommended[:k], start=1):
        rel = 1.0 if iid in relevant else 0.0
        dcg += rel / math.log2(i + 1)
    ideal_hits = min(len(relevant), k)
    idcg = sum(1.0 / math.log2(i + 1) for i in range(1, ideal_hits + 1))
    return dcg / idcg if idcg > 0 else 0.0


def catalog_coverage(all_recommended: Iterable[str], catalog: Set[str]) -> float:
    """Provided: Coverage = |unique recommended items| / |catalog|"""
    unique_rec = set(all_recommended)
    return len(unique_rec) / max(1, len(catalog))


# -------------------------------------------------------------
#                 EVALUATION HARNESS
# -------------------------------------------------------------
def evaluate_model(model_name: str,
                   recommend_fn,
                   train: pd.DataFrame,
                   test: pd.DataFrame,
                   k: int,
                   catalog_items: Set[str]) -> Dict[str, float]:
    """
    recommend_fn: (user_id:str, user_seen:Set[str], k:int)->List[Tuple[item_id, score]]
    Returns averaged metrics across users with non-empty test sets.
    """
    # Build user->seen and user->relevant
    seen_by_user = defaultdict(set)
    for row in train.itertuples(index=False):
        seen_by_user[str(row.user_id)].add(str(row.item_id))
    test_by_user = defaultdict(set)
    for row in test.itertuples(index=False):
        test_by_user[str(row.user_id)].add(str(row.item_id))

    precisions, recalls, maps, ndcgs = [], [], [], []
    all_rec_items = []

    for uid, relevant in test_by_user.items():
        seen = seen_by_user.get(uid, set())
        recs = recommend_fn(uid, seen, k)
        rec_ids = [iid for iid, _ in recs]
        if len(rec_ids) == 0:
            continue
        all_rec_items.extend(rec_ids)
        precisions.append(precision_at_k(rec_ids, relevant, k))
        recalls.append(recall_at_k(rec_ids, relevant, k))
        maps.append(average_precision_at_k(rec_ids, relevant, k))
        ndcgs.append(ndcg_at_k(rec_ids, relevant, k))

    coverage = catalog_coverage(all_rec_items, catalog_items)
    return {
        "model": model_name,
        "users_evald": len(precisions),
        f"P@{k}": float(np.mean(precisions) if precisions else 0.0),
        f"R@{k}": float(np.mean(recalls) if recalls else 0.0),
        f"MAP@{k}": float(np.mean(maps) if maps else 0.0),
        f"nDCG@{k}": float(np.mean(ndcgs) if ndcgs else 0.0),
        "coverage": float(coverage),
    }


# -------------------------------------------------------------
#                 MAIN: RUN COMPARISON
# -------------------------------------------------------------
def run(data_dir: str,
        k: int = 10,
        test_ratio: float = 0.2,
        like_threshold: float = 4.0,
        popularity_method: str = "count",
        min_pop_interactions: int = 1) -> pd.DataFrame:
    interactions, items = load_ml100k(data_dir)
    train, test = train_test_split_by_user(interactions, test_ratio=test_ratio, seed=42)
    catalog = set(items["item_id"].astype(str).tolist())

    # Popularity (runs out of the box)
    pop = PopularityModel.fit(train, method=popularity_method, min_interactions=min_pop_interactions)
    eval_pop = evaluate_model(
        f"Popularity[{popularity_method}]",
        lambda uid, seen, kk: pop.recommend(seen, kk),
        train, test, k, catalog)

    rows = [eval_pop]

    # Uncomment these lines as you complete the TODOs:
    # Content-based
    content = ContentModel.fit(items)
    profiles = content.build_user_profiles(train, like_threshold=like_threshold)
    eval_content = evaluate_model("Content",
                                  lambda uid, seen, kk: content.recommend(uid, seen, profiles, kk),
                                  train, test, k, catalog)
    rows.append(eval_content)

    # User-CF
    ucf = UserCFModel.fit(train)
    eval_ucf = evaluate_model("User-CF",
                              lambda uid, seen, kk: ucf.recommend(uid, seen, kk),
                              train, test, k, catalog)
    rows.append(eval_ucf)

    return pd.DataFrame(rows)


if __name__ == "__main__":
    data_dir = '../ml-latest-small'
    k = 10  # 3, 5, 7
    test_ratio = 0.2  # Per-user test ratio
    like_threshold = 4  # Explicit like threshold for content model
    popularity_method = "sum_rating"  # Popularity scoring method Choices: "count","sum_rating","avg_log_count","bayes_avg"
    min_pop_interactions = 1  # Minimum interactions to keep an item for popularity ranking

    df = run(
        data_dir=data_dir,
        k=k,
        test_ratio=test_ratio,
        like_threshold=like_threshold,
        popularity_method=popularity_method,
        min_pop_interactions=min_pop_interactions
    )
    print('\n')
    with pd.option_context('display.max_columns', None):
        print(df.to_string(index=False))